I took Anuke's example mod and removed a few items. I then edited most-to-all the files to make everything more over powered and easier to obtain (everything in the mod is now free to craft). Some people would kind of see this like a cheat mod, idk it's your opinion. Maybe in the future I can edit other modder's mods if you want me to and/or just make modpacks for people (by combining multiple mods into 1 folder mod thing). Might add new things in a much later update if I feel like it.

Creator: Founder
Discord: HNU Founder.lua#5046